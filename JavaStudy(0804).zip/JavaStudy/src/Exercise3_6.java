
public class Exercise3_6 {

	public static void main(String[] args) {
		int num = 24;
		System.out.println(num%10 != 0 ? (num/10*10+10) - num : 0);   //0이 아닐 경우(2.4*10+10) - 24 = 6 
																				
	}

}
