
public class Exercise3_4 {

	public static void main(String[] args) {
		int num = 456;
		System.out.println(num == 456 ? num/100*100 : "456이 아님");

	}

}
