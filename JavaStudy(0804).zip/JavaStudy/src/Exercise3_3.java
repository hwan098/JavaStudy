
public class Exercise3_3 {

	public static void main(String[] args) {
		int num = 10;
		System.out.println(num > 0 ?"양수" : (num == 0 ? "0" : "음수"));

	}

}
