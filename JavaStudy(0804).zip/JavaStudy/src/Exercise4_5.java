
public class Exercise4_5 {

	public static void main(String[] args) {
		int i = 0;
		
		while(i<=10) {
			System.out.println();
			i++;
			int j = 1;
			while(j<=i) {
				System.out.print("*");
				j++;
			}
		}
	
	}	
}
