
public class Exersice3_5 {

	public static void main(String[] args) {
		int num = 333;
		System.out.println(num == 333 ? (num/10*10)+1 : "333이 아님");

	}

}
