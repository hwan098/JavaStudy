
public class Exercise4_7 {

	public static void main(String[] args) {
		int value = (int)(Math.random()*6)+1; //실수형으로 난수를 발생시키므로 정수형으로 바꿔줘야하고 0부터 5까지만 6자리를 나타내므로 +1도 같이 써준다.
		
		System.out.println("value: " + value);

	}

}
