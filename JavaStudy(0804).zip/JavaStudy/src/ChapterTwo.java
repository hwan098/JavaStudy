
public class ChapterTwo {

	public static void main(String[] args) {
		System.out.println(true + "");
		System.out.println('B'); 
		System.out.println('A' + 'B');
		System.out.println('1' + 2);
		System.out.println('1' + '2');
		System.out.println('J' + "ava");
		
		int a = 10;
		int b = 2;
		
		
		System.out.printf("%d / %f  = %f\n", a, (float)b, a/(float)b);
		
		
	}

}
